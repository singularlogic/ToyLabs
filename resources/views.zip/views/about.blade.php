@extends('layouts.default', ['class' => ''])

@section('title', 'About')

@section('content')
        <!-- About -->
        <div class="ui main container">

        </div>
@endsection
