@extends('layouts.default', ['class' => ''])

@section('title', 'Feed')

@section('content')
        <!-- Feed -->
        <div class="ui main container">
            <notifications-page></notifications-page>
        </div>
@endsection
